<?php

    require '../src/routes.php'

?>