window.onload = function() {
    alert("hola");
};